# XCORD

**X actions, without leaving Discord.**

XCORD is a lightweight Chrome extension that adds one-click X actions directly next to X/Twitter links inside Discord.

## Features

- **Follow** X profiles directly from Discord.
- **Like** X posts with a dedicated button.
- **Repost** independently from Like.
- Keeps Discord focused while the action runs in a temporary background tab.
- Automatically closes the temporary X tab when the action finishes.
- Detects profiles and posts that are already followed, liked, or reposted.
- Clean, native-looking controls designed to fit Discord's interface.
- Fully English interface.

## Installation

1. Download and extract the XCORD ZIP file.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `XCORD-v1.4.0` folder.
6. Refresh Discord.
7. Make sure you are signed in to X on the same Chrome profile.

## Usage

- X profile links receive a **Follow @username** button.
- X post links receive separate **Like** and **Repost** buttons.
- If an action fails, hover the retry button to view the error message.

## How it works

XCORD opens the relevant X page in a temporary inactive tab, performs the selected action, verifies the result, and closes the tab automatically. Your Discord tab remains active.

## Permissions

XCORD requests only the permissions needed to detect links in Discord and perform actions on X:

- `tabs` — creates and closes the temporary background X tab.
- `scripting` — performs the requested X action in that tab.
- Access to Discord — detects X links and adds action buttons.
- Access to X/Twitter — performs Follow, Like, and Repost actions.

XCORD does not require an X API key.

## Version

Current version: **1.4.0**
