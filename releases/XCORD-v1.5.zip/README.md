# XCORD

X actions, directly from Discord.

XCORD adds quick X actions to Discord links, including Follow, Like, Repost, Raid, and Copy Reply.

## v1.5

- Replaced the `01/` section marker with a live numeric preset counter positioned directly beside `Raid Presets`
- Removed the separate `6 presets` badge
- Changed the counter to a near-black treatment so it reads as part of the interface instead of an accent block
- Reduced reserved footer/status space for a tighter bottom edge
- Reduced popup width to 368px with denser, more balanced vertical rhythm
- XCORD wordmark now uses the Discord-inspired blurple accent beside the logo
- Kept Follow, Like, Repost, and Raid in a compact four-cell action strip
- Tightened the Raid Presets editor, metadata row, and button proportions
- Updated footer branding to `XCORD XKATSURA @2026`
- Existing extension behavior remains unchanged

## Install locally

1. Extract the extension folder.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted XCORD folder.
6. Refresh Discord.
